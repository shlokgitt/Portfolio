import { Navigation } from "@/components/Navigation";
import HeroSequenceLoader from "@/components/HeroSequence";

export default function Home() {
  return (
    <main>
      {/* Navigation */}
      <Navigation />

      {/* Hero — 600vh pinned scroll-driven animation */}
      <HeroSequenceLoader />

      {/* Footer — minimal dark section so page doesn't end abruptly */}
      <footer
        className="footer-section"
        style={{
          minHeight: "50vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "4rem 2rem",
          gap: "1.5rem",
        }}
        id="contact"
      >
        <p
          style={{
            fontFamily: "var(--font-serif)",
            fontStyle: "italic",
            fontSize: "clamp(1.25rem, 3vw, 2rem)",
            color: "var(--color-accent)",
            textAlign: "center",
          }}
        >
          Nothing remains but beauty.
        </p>
        <p
          style={{
            fontSize: "0.8125rem",
            color: "var(--color-text-muted)",
            letterSpacing: "0.06em",
            textTransform: "uppercase",
          }}
        >
          © {new Date().getFullYear()} · Crafted with obsessive detail
        </p>
      </footer>
    </main>
  );
}
